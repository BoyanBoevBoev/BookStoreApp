package org.bosch.intern.io;

import org.bosch.intern.exception.BookStoreException;

import java.io.*;
import java.util.List;

public class Writer implements Closeable {
    private PrintWriter printWriter;

    public Writer(String fileName) {
        try {
            this.printWriter = new PrintWriter(new FileWriter(fileName, true));
        } catch (IOException e) {
            throw new BookStoreException("File not found");
        }
    }

    public void write(List<String> csvData) {
        printWriter.write(String.join(",",csvData));
        printWriter.flush();
    }


    @Override
    public void close() throws IOException {
        printWriter.close();
    }
}
