package org.bosch.intern.core;

public interface Engine extends Runnable {

}
