package org.bosch.intern.repository;

import org.bosch.intern.entity.Author;
import org.bosch.intern.entity.Book;
import org.bosch.intern.io.Reader;
import org.bosch.intern.io.Writer;
import org.bosch.intern.util.AuthorMapper;
import org.bosch.intern.util.ConstantMessages;
import org.bosch.intern.util.ExceptionMessage;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

public class AuthorRepositoryImpl implements AuthorRepository {
    private final Collection<Author> authorCollection;
    private Reader reader;
    private Author author;
    private static final String FILE_NAME_AUTHOR = "AuthorRepository.csv";

    public AuthorRepositoryImpl() {
        this.authorCollection = new ArrayList<>();
    }

    @Override
    public void addNewAuthor(Author author) {
        if (isSuccessful(author)) {
            authorCollection.add(author);
            System.out.printf((ConstantMessages.SUCCESSFULLY_CREATED_AUTHOR) + "%n", author.getName());
            Writer writer = new Writer(FILE_NAME_AUTHOR);
            writer.write(AuthorMapper.toList(author));
        } else {
            System.out.printf(ExceptionMessage.AUTHOR_ALREADY_EXISTS + "%n", author.getName());
        }

    }

    @Override
    public Collection<Author> getAuthorCollection() {
        reader = new Reader(FILE_NAME_AUTHOR);
        List<String> authorData = reader.read();
        while (authorData != null) {
            author = new Author(Integer.parseInt(authorData.get(0)),authorData.get(1),authorData.get(2));
                authorCollection.add(author);
                authorData = reader.read();
            }
        return this.authorCollection;
        }



    private boolean isSuccessful(Author author) {
        String name = author.getName();
        reader = new Reader(FILE_NAME_AUTHOR);
        List<String> authorData;
        authorData = reader.read();
        while (authorData != null && authorData.size() > 1) {
            Author currentAuthor = AuthorMapper.toEntity(authorData);
            if (currentAuthor.getName().equalsIgnoreCase(name)) {
                return false;
            }
            authorData = reader.read();
        }
        return true;
    }


}