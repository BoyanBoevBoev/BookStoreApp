package org.bosch.intern.util;

import org.bosch.intern.entity.Book;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class BookMapper {

    public static Book toEntity(List<String> csvData) {
        Book book = new Book(Integer.parseInt(csvData.get(0)), csvData.get(1), Integer.parseInt(csvData.get(2)),
                csvData.get(3), Integer.parseInt(csvData.get(4)), Double.parseDouble(csvData.get(5)));
        return book;
    }

    public static List<String> toList(Book book) {
        return Arrays.asList(String.valueOf(book.getId()), book.getName(), String.valueOf(book.getAuthor_id()), book.getDate(), String.valueOf(book.getQuantity()),
                String.valueOf(book.getPrice()));
    }
}
