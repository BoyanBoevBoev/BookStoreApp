package org.bosch.intern.util;

public enum Command {
    AddAuthor,
    AddBook,
    GetAllBooksAndAuthors,
    GetBookById,
    GetAllAuthors,
    GetAllBooksByAuthor,
    Exit
}
