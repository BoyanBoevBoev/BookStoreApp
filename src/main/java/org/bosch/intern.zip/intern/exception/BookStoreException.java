package org.bosch.intern.exception;

public class BookStoreException extends RuntimeException {

        private String errorMessage;

        public BookStoreException(String errorMessage) {
                this.errorMessage = errorMessage;
        }
}
