package org.bosch.intern.core;

import org.bosch.intern.service.BookStoreService;
import org.bosch.intern.util.Command;

import java.util.Arrays;
import java.util.Scanner;

public class EngineImpl implements Engine {
    private Scanner scanner = new Scanner(System.in);
    private BookStoreService bookStoreService;
    @Override
    public void run() {
        while (true) {
            scanner = new Scanner(System.in);
            String[] tokens = scanner.nextLine().split("\\s+");
            Command command = Command.valueOf(tokens[0]);
            String[] data = Arrays.stream(tokens).skip(1).toArray(String[]::new);
            switch (command){
                case AddAuthor:
                    bookStoreService.addAuthor(data);


            }
        }
    }
}
