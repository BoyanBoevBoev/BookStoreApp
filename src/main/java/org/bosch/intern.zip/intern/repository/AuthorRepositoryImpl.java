package org.bosch.intern.repository;

import org.bosch.intern.entity.Author;
import org.bosch.intern.entity.Book;
import org.bosch.intern.io.Reader;
import org.bosch.intern.io.Writer;
import org.bosch.intern.util.ConstantMessages;
import org.bosch.intern.util.ExceptionMessage;

import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Collection;

public class AuthorRepositoryImpl implements AuthorRepository {
    private Collection<Author> authorCollection;
    private Reader reader;
    private Author author;
    private static final String FILE_NAME_AUTHOR = "AuthorRepository.csv";

    public AuthorRepositoryImpl() {
        this.authorCollection = new ArrayList<>();
    }

    @Override
    public void addNewAuthor(Author author) {
        if (isSuccessful(author)) {
            authorCollection.add(author);
            System.out.printf((ConstantMessages.SUCCESSFULLY_CREATED_AUTHOR) + "%n", author.getName());
            Writer writer = new Writer("AuthorRepository.csv");
            writer.writeAuthor(author);
        } else {
            System.out.printf(ExceptionMessage.AUTHOR_ALREADY_EXISTS + "%n", author.getName());
        }

    }

    @Override
    public Collection<Author> getAuthorCollection() {
        reader = new Reader(FILE_NAME_AUTHOR);
        String currentLine = "";
        while ((currentLine = reader.read()) != null) {
            String[] tokens = currentLine.split(",");
            if (tokens.length > 0) {
                author = new Author(Integer.parseInt(tokens[0]), tokens[1],
                        tokens[2]);
                authorCollection.add(author);
            }
        }
        return this.authorCollection;
    }


    private boolean isSuccessful(Author author) {
        String name = author.getName();
        reader = new Reader(FILE_NAME_AUTHOR);
        String currentLine = reader.read();
        String[] separatedLine;
        while (currentLine != null && !currentLine.trim().isEmpty()) {
            separatedLine = currentLine.split(",");
            if (separatedLine[1].trim().equalsIgnoreCase(name)) {
                return false;
            }
            currentLine = reader.read();
        }
        return true;
    }


}