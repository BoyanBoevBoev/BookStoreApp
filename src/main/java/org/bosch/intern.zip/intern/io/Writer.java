package org.bosch.intern.io;

import org.bosch.intern.entity.Author;
import org.bosch.intern.entity.Book;
import org.bosch.intern.util.BookMapper;

import javax.naming.NamingEnumeration;
import java.io.*;
import java.util.List;

public class Writer implements Closeable {
    private PrintWriter printWriter;

    public Writer(String fileName) {
        try {
            this.printWriter = new PrintWriter(new FileWriter(fileName, true));
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }

    // Вместо Автор и Книга да имам String[] или Лист + close.
    public void write(List<String> csvData) {
        BookMapper bookMapper = new BookMapper();
        printWriter.println(csvData);
//        printWriter.printf("%d, %s, %s%n",author.getId(),author.getName(),author.getDate());
        printWriter.flush();
    }


    @Override
    public void close() throws IOException {
        printWriter.close();
    }
}
