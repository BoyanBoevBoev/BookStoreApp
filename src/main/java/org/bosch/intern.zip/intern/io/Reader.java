package org.bosch.intern.io;

import org.bosch.intern.exception.BookStoreException;
import org.bosch.intern.util.ExceptionMessage;

import java.io.*;
import java.util.Arrays;
import java.util.List;

public class Reader implements Closeable {
    private BufferedReader bufferedReader;

    public Reader(String fileName) {
        try {
            this.bufferedReader = new BufferedReader(new FileReader(fileName));
        } catch (FileNotFoundException e) {
            throw new BookStoreException(ExceptionMessage.SERVER_ERROR_MESSAGE);
        }
    }

    // В read да връщам List<String>
    public List<String> read() {
        try {
            String currentLine = bufferedReader.readLine();
            List<String> stringList;
            return stringList = Arrays.stream(currentLine.split(",")).toList();

        } catch (IOException e) {
            try {
                this.close();
            } catch (IOException ex) {
                throw new RuntimeException(ex);
            }
            throw new RuntimeException(e);
        }
    }


    @Override
    public void close() throws IOException {
            bufferedReader.close();
    }
}
