import org.bosch.intern.core.EngineImpl;
import org.bosch.intern.entity.Author;
import org.bosch.intern.entity.Book;
import org.bosch.intern.service.BookStoreService;

public class Main {
    public static void main(String[] args) {
        BookStoreService bookStoreService = new BookStoreService();
        EngineImpl engine = new EngineImpl();
        engine.run();
//       Book book = new Book(1, "Vinetu", 1, "05.12.2005", 56, 9.99);
//      Book book2 = new Book(2, "Moqta Borba", 2, "05.12.2025", 98, 19.99);
//       Book book3 = new Book(3, "Moqta Borba 2", 2, "05.12.2125", 53, 959.99);
//       Author author = new Author(1, "Boyko Borisov", "09.10.1960");
//        Author author1 = new Author(2, "Volen Siderov", "25.07.1958");
//       Author author2 = new Author(3, "Ivan Vazov", "25.07.1846");
//        bookStoreService.addBook(book);
//       bookStoreService.addBook(book2);
//       bookStoreService.addBook(book3);
//       bookStoreService.addAuthor(author1);
//       bookStoreService.addAuthor(author1);
//       bookStoreService.addAuthor(author2);
//        bookStoreService.getAllBooksByAuthor(2).forEach(b -> System.out.println(b.getName()));
//      System.out.println(bookStoreService.getAllAuthors().size());
//        System.out.println(bookStoreService.getAllBooks().size());
//  System.out.println(bookStoreService.getBookById(1).getName());
//    bookStoreService.getAllBooks().forEach(book1 -> System.out.println(book1.getName()));
//      bookStoreService.getAllBooksAndAuthors().forEach((key, value) -> System.out.printf("Book name - %s," +
//                       "Published - %s, Price - %.2f, Author name - %s%n", key.getName(),
//              key.getDate(), key.getPrice(), value.getName()));
//    }
    }
}
