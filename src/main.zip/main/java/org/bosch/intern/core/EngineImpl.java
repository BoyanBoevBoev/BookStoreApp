package org.bosch.intern.core;

import org.bosch.intern.entity.Book;
import org.bosch.intern.service.BookStoreService;
import org.bosch.intern.util.Command;

import java.util.Arrays;
import java.util.List;
import java.util.Scanner;

public class EngineImpl implements Engine {
    private Scanner scanner = new Scanner(System.in);
    private BookStoreService bookStoreService;

    @Override
    public void run() {
        while (true) {
            scanner = new Scanner(System.in);
            bookStoreService = new BookStoreService();
            String[] tokens = scanner.nextLine().split("-");
            boolean exitCommand = false;
            Command command = Command.valueOf(tokens[0]);
            List<String> data = Arrays.stream(tokens).skip(1).toList();
            switch (command) {
                case AddAuthor:
                    bookStoreService.addAuthor(data);
                    break;
                case AddBook:
                    bookStoreService.addBook(data);
                    break;
                case GetAllBooksAndAuthors:
                    getAll();
                    break;
                case GetBookById:
                    System.out.println(bookStoreService.getBookById(Integer.parseInt(data.get(0))).getName());
                    break;
                case GetAllAuthors:
                    bookStoreService.getAllAuthors().forEach(author -> System.out.println(author.getName()));
                    break;
                case GetAllBooks:
                    bookStoreService.getAllBooks().forEach(book -> System.out.println(book.getName()));
                    break;
                case GetAllBooksByAuthor:
                    bookStoreService.getAllBooksByAuthor(Integer.parseInt(data.get(0)));
                    break;
                case Exit:
                    exitCommand = true;
                    break;
            }
            if (exitCommand){
                break;
            }
        }
    }

    private void getAll() {
        bookStoreService.getAllBooksAndAuthors().forEach((key, value) -> System.out.printf("Book name - %s," +
                    "Published - %s, Price - %.2f, Author name - %s%n", key.getName(),
            key.getDate(), key.getPrice(), value.getName()));
    }
}
