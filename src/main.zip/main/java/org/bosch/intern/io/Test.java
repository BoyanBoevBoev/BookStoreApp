package org.bosch.intern.io;

import java.io.FileNotFoundException;

public class Test {
    public static void main(String[] args) {
        RuntimeException runtimeException = new RuntimeException();
        FileNotFoundException fileNotFoundException;
    }
}
