package org.bosch.intern.util;

public class ExceptionMessage {
    //already exists
    public static final String AUTHOR_ALREADY_EXISTS = "Author: %s already exists.";
    public static final String BOOK_ALREADY_EXISTS = "Book: %s already exists.";
    public static final String SERVER_ERROR_MESSAGE = "File not found on server.";
}
